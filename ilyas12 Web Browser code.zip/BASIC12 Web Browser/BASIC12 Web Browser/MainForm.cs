﻿/*
 * Created by SharpDevelop.
 * User: ilyas
 * Date: 9/28/2018
 * Time: 8:19 PM
 * 
 * Made By 
 */
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace BASIC12_Web_Browser
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public partial class MainForm : Form
	{
		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			//
			// TODO: Add constructor code after the InitializeComponent() call.
			//
		}
		void Button1Click(object sender, EventArgs e)
		{
			NAVIGATEbrowser();
		}
		void NAVIGATEbrowser()
		{
			this.webBrowser1.Navigate(textBox1.Text);
		}
		void TextBox1KeyPress(object sender, KeyPressEventArgs e)
		{
			if (e.KeyChar == 13)
			{
				NAVIGATEbrowser();
			}
		}
		void WebBrowser1Navigating(object sender, WebBrowserNavigatingEventArgs e)
		{
			this.textBox1.Enabled = false;
			this.button1.Enabled = false;
		}
		void WebBrowser1Navigated(object sender, WebBrowserNavigatedEventArgs e)
		{
			this.button1.Enabled = true;
			this.textBox1.Enabled = true;
			this.textBox1.Text = webBrowser1.Url.AbsoluteUri;
		}
		void Button2Click(object sender, EventArgs e)
		{
			Form1 f1 = new Form1();
			f1.ShowDialog();
		}
	}
}
